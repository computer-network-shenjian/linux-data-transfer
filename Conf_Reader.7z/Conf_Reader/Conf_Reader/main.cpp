#pragma warning( disable : 4244)
#include <iostream>
#include <bitset>
#include <algorithm>
// #include <arpa/inet.h>

#include "ConfReader.h"
#include "IniParser.h"

struct HeaderMAC {
	uint8_t mac_dest_addr[6]{};   // 6 bytes
	uint8_t mac_src_addr[6]{};    // 6 bytes
	uint16_t protocol_type = 0x0800;     // 2 bytes
};

// IP header, 20 bytes to 60 bytes, SJ fix it to be 20 bytes.
struct HeaderIP {
	// [version, 4 bit][header length, 4 bit]
	uint8_t version_and_header_length = 0x45;  // 1 byte
	uint8_t service_type = 0x00;   // 1 byte
	uint16_t packet_length = 0;    // 2 bytes
	uint16_t packet_ID = rand() % 65536;   // 2 bytes, 0~65535
										 // [flags, 3 bits][offset, 13 bytes]
	uint16_t slice_info = 0;    // 2 bytes
	uint8_t ttl = 64;    // 1 byte
	uint8_t type_of_protocol = 0x06;   // 1 byte
	uint16_t ip_check_sum = 0;      // 2 bytes
	uint32_t source_addr = 0;   // 4 bytes
	uint32_t dest_addr = 0;     // 4 bytes
								// SJ fix IP header to be 20 bytes, so ip_info is not needed.
								//uint8_t ip_info[40];    // 0-40 bytes, must be divisible by 4
};

// TCP header, 20 bytes to 60 bytes.
struct HeaderTCP {
	uint16_t source_port = 1 + rand() % 65535;   // 2 bytes, 1~65535
	uint16_t dest_port = 80;     // 2 bytes
	uint32_t seq = rand() % 2147483648;   // 4 bytes, 0~2^31-1
	uint32_t ack = rand() % 2147483648;   // 4 bytes, 0~2^31-1
										  // [data offset, 4 bit][all zeros, 3 bit][flags, 9 bit]
	uint16_t data_offset_and_flags = 0x5010;     // 2 bytes
	uint16_t window_size = rand() % 65536;   // 2 bytes, 0~65535
	uint16_t tcp_check_sum = 0;     // 2 bytes
	uint16_t urgent_pointer = 0;    // 2 bytes
	uint8_t tcp_info[40]{};    // 0-40 bytes, must be divisible by 4
};

struct HeaderTCP get_headertcp(ConfReader& config)
{
	struct HeaderTCP temp;

	temp.source_port = config.GetParam<uint16_t>("�����.srcport");
	temp.dest_port = config.GetParam<uint16_t>("�����.dstport");
	temp.data_offset_and_flags &= 0x0000; // set the 16 bits to zero
	temp.data_offset_and_flags |= (config.GetParam<uint16_t>("�����.offset") << 12); // bit wise or for higher 4 bits
	std::bitset<16> flag(config.GetParam<std::string>("�����.flag"));
	temp.data_offset_and_flags |= *(uint16_t*)&flag;// or with lower 6 bits

	return temp;
}

struct HeaderIP get_headerip(ConfReader& config)
{
	struct HeaderIP temp;

	temp.ttl = config.GetParam<uint8_t>("�����.ttl");
	
	/*
	struct in_addr addr;
	inet_aton(config.GetParam<std::string>("�����.srcip").c_str(), &addr);
	temp.source_addr = addr.s_addr;

	inet_aton(config.GetParam<std::string>("�����.dstip").c_str(), &addr);
	temp.dest_addr = addr.s_addr;
	*/

	temp.slice_info &= 0x0000; // set the 16 bits to zero
	std::bitset<16> flag(config.GetParam<std::string>("�����.flag"));
	temp.slice_info |= (*(uint16_t*)&flag << 13); // or with higher 3 bits
	temp.slice_info |= config.GetParam<uint16_t>("�����.offset");// or with lower 13 bits


	return temp;
}

struct HeaderMAC get_headermac(ConfReader& config)
{
	// constexpr char hexmap[] = { '0', '1', '2', '3', '4', '5', '6', '7',
	// 	'8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	struct HeaderMAC temp;
	std::string srcmac = config.GetParam<std::string>("������·��.srcmac");
	std::string dstmac = config.GetParam<std::string>("������·��.dstmac");
	// srcmac.erase(std::remove(srcmac.begin(), srcmac.end(), ':'), srcmac.end());
	// dstmac.erase(std::remove(dstmac.begin(), dstmac.end(), ':'), dstmac.end());
	
	for(int i = 0; i < 6; i++) {
		temp.mac_src_addr[i] = std::stoul(srcmac.substr(i * 3, 2), nullptr, 16);
		temp.mac_dest_addr[i] = std::stoul(dstmac.substr(i * 3, 2), nullptr, 16);
	}

	return temp;
}

int main() {
	try {
		ConfReader config(std::make_unique<IniParser>());
		config.LoadFile("./tests/files/network.conf");
		/*
		// Creates ConfReader class instance with IniParser as parameter
		ConfReader config(std::make_unique<IniParser>());
		// Loads file and stores found parameters
		config.LoadFile("./tests/files/test_file.ini");

		// Gets parameter as string, throws an exception if it does not exist
		std::cout << config.GetParam("personal_info.name") << std::endl;
		// Gets parameter with specified return type, throws an exception if conversion is not possible
		std::cout << config.GetParam<int>("personal_info.age") << std::endl;
		std::cout << config.GetParam<int>("�����.srcport") << std::endl;

		// Loads second configuration file, overrides existing parameters
		config.LoadFile("./tests/files/test_file2.ini");
		// Checks if parameter exist before accessing it
		if (config.Has("personal_info.age") == true) {
			auto age = config.GetParam<int>("personal_info.age");
			std::cout << age << std::endl << std::endl;
			// Do something with parameter...
		}


		// Loops through all parameters
		for (auto & sample : config.GetAllParams()) {
			std::cout << sample.first << " : " << sample.second << std::endl;
			// sample.second == std::string("section_name") -> begining of "sample.first" section parameters
		}


		// Deletes previously stored data and loads new file
		config.Reset();
		config.LoadFile("./tests/files/test_file3.ini");


		// Optional functionality - Read different configuration file format(.csv) and load file
		// config.ChangeParser(std::make_unique<CsvParser>()	);
		// config.LoadFile("test_file.csv");

		*/


	}
	catch (const std::exception & e) {
		std::cout << e.what() << std::endl;
	}

	system("pause");

	return 0;
}
